/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classi;

import java.util.ArrayList;

/**
 *
 * @author wuyi
 */
public class GestioneCorsi extends Gestore{

    private static  ArrayList<Corso> corsi=new ArrayList<>();

   public GestioneCorsi(ArrayList<String>dati) {
        String separatore=";";
        for(String i: dati){
           
            String[] d=i.split(separatore);
           Corso tmp= new Corso(d[0],d[1],Integer.parseInt(d[2]));
            corsi.add(tmp);
        }
    }
    
    public GestioneCorsi() {
        corsi = new ArrayList<>();
    }

    public void creaCorso(String codice, String nome, int durata) {
        corsi.add(new Corso(codice,nome,durata));
        System.out.println("s");
    }
    
    public ArrayList<Corso>  visualizzaCorsi(){
        return corsi;
    }
    public void modificaCorso(String codice, String nome, int durata){
        for(Corso i : corsi){
            if(i.getCodiceCorso().equals(codice)){
                i.setDurataAnni(durata);
                i.setNomeCorso(nome);
            }
        }
        
    }
    
    public void eliminaCorso(){
        System.out.println("eliminaCorso");
    }
    public static Corso cercaCorso(String codice){
             for(Corso i : corsi){
            if(i.getCodiceCorso().equals(codice))return i;
               }
             return null;
    }
}
