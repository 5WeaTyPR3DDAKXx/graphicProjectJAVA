/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classi;

import java.util.ArrayList;

/**
 *
 * @author wuyi
 */
public class GestioneDiscipline {
    private static ArrayList<Disciplina>discipline=new ArrayList<>();

    public GestioneDiscipline(ArrayList<String>dati) {
      String separatore=";";
        for(String i: dati){
            Disciplina tmp;
            String[] d=i.split(separatore);
            Corso dis=GestioneCorsi.cercaCorso(d[3]);
            //if(dis==null)throw new IllegalArgumentException("file csv sbagliato riprova");
             tmp = new Disciplina(d[0],d[1],Integer.parseInt(d[2]),dis);
            discipline.add(tmp);
        }
    }
    
    
    
    public void creaDisciplina(String codiceDisciplina,String nomeDisciplina,int cfu,Corso corsoDisciplina)
    {
        discipline.add(new Disciplina(codiceDisciplina,nomeDisciplina,cfu,corsoDisciplina));
        
    }
    public static Disciplina cercaDisciplina(String codice){
        for(Disciplina i :discipline){
            if(i.getCodiceDisciplina().equals(codice))return i ;
        }
        return null;
    }
    
    
    public  ArrayList<Disciplina> visualizzaDiscipline(){
        return discipline;
    }
    
}
