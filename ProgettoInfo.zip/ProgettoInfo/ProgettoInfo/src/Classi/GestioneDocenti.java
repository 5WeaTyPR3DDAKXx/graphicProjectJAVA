/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classi;

import java.util.ArrayList;

/**
 *
 * @author wuyi
 */
public class GestioneDocenti {
    private ArrayList<Docente>docenti;
    
    // insegna una sola disciplina non ancora implementata
    public void inserisciDocente(String matricolaDocente, String nome, String cognome, Disciplina disciplinaAssegnata){
        docenti.add( new Docente(matricolaDocente,  nome,  cognome,  disciplinaAssegnata));
    }
    
    
    
    
}
