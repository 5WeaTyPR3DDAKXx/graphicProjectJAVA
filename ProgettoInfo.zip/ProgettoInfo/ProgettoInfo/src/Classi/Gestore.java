/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classi;

/**
 *
 * @author wuyi
 */
public class Gestore {

    public  GestioneDiscipline gd ;
    public  GestioneDocenti gdoc ;
    public  GestioneCorsi gc ;
    public  GestioneStudenti gs;
    public  GestioneAppelli ga ;
    GestioneLettura gl= new GestioneLettura();

    public Gestore() {
         gd = new GestioneDiscipline(gl.readFile("discipline.csv"));
         gdoc = new GestioneDocenti(gl.readFile("docenti.csv"));
         gc = new GestioneCorsi(gl.readFile("corsi.csv"));
         gs = new GestioneStudenti(gl.readFile("studenti.csv"));
         ga = new GestioneAppelli(gl.readFile("appelli.csv"));
    }
    
    public void stampa(){
        System.out.println("xx");
    }
}
