/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classi;

import java.util.ArrayList;

/**
 *
 * @author wuyi
 */
public class GestioneStudenti {// possibilita di iscriversi solo a un corso non implementato=========
    public static ArrayList<Studente>studenti;

    public GestioneStudenti(ArrayList<Studente> studenti) {
        GestioneStudenti.studenti = studenti;
    }

    public GestioneStudenti() {
        studenti=new ArrayList<>();
    }
    
    public void registraStudente(String matricola,String nome,String cognome,Corso corso){
        Studente s=new Studente(matricola,nome,cognome,corso);
        studenti.add(s);
    }
    
    
}
