/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classi;
import java.util.ArrayList;
import java.util.Date;
/**
 *
 * @author predieric
 */
public class Appello {
    String idAppello;
    String data;
    Disciplina disciplinaAssegnata;
    ArrayList<Studente>studeniIscritti;

    public Appello(String idAppello, String data, Disciplina disciplinaAssegnata, ArrayList<Studente> studeniIscritti) {
        this.idAppello = idAppello;
        this.data = data;
        this.disciplinaAssegnata = disciplinaAssegnata;
        this.studeniIscritti = studeniIscritti;
    }

    public ArrayList<Studente> getStudeniIscritti() {
        return studeniIscritti;
    }
    
}
