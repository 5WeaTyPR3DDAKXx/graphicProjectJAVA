/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classi;

import java.util.ArrayList;

/**
 *
 * @author wuyi
 */
public class GestioneAppelli {
    public static ArrayList<Appello>appelli;
    
    public GestioneAppelli(ArrayList<String>dati) {
        String separatore=";";
        for(String i: dati){
            String[] d=i.split(separatore);
             
        }
    }
    public void addAppello(Appello a){
        appelli.add(a);
    }
    public void iscrizioneAppello(Studente s,Appello a){
       s.getAppelliIscritti().add(a);
       a.getStudeniIscritti().add(s);
    }
    
}
