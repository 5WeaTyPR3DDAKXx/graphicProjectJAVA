/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MainCalled;

import Classi.Gestore;

/**
 *
 * @author crist
 */
public class GlobalGestor {
        public static Gestore gestorone=new Gestore();
}
