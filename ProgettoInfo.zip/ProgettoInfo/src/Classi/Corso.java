/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classi;

/**
 *
 * @author predieric
 */
import java.util.ArrayList;
public class Corso {
    String codiceCorso;
    String nomeCorso;
    int durataAnni;
    ArrayList<Disciplina>disciplineAssegnati;

    public Corso(String codiceCorso, String nomeCorso, int durataAnni) {
        this.codiceCorso = codiceCorso;
        this.nomeCorso = nomeCorso;
        this.durataAnni = durataAnni;
        disciplineAssegnati=new ArrayList<>();
    }

    @Override
    public String toString() {
        return "Corso "+"[" + "codiceCorso=" + codiceCorso + ", nomeCorso=" + nomeCorso + ", durataAnni=" + durataAnni +']';
    }

    public String getCodiceCorso() {
        return codiceCorso;
    }

    public void setNomeCorso(String nomeCorso) {
        this.nomeCorso = nomeCorso;
    }

    public void setDurataAnni(int durataAnni) {
        this.durataAnni = durataAnni;
    }
    public void aggiungiDiscipline(Disciplina d){
        disciplineAssegnati.add(d);
    }
    

}
