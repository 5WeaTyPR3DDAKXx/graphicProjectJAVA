/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classi;

import java.util.ArrayList;

/**
 *
 * @author wuyi
 */
public class GestioneDocenti {
    private static ArrayList<Docente>docenti=new ArrayList<>();
    
    // insegna una sola disciplina non ancora implementata

    public GestioneDocenti(ArrayList<String> dati) {
          String separatore=";";
        for(String i: dati){
            Docente tmp;
            String[] d=i.split(separatore);
            Disciplina dis=GestioneDiscipline.cercaDisciplina(d[3]);
            if(dis==null)throw new IllegalArgumentException("file csv sbagliato riprova");
            else tmp = new Docente(d[0],d[1],d[2],dis);
            docenti.add(tmp);
        }
    }
    
    
    
    public void inserisciDocente(String matricolaDocente, String nome, String cognome, Disciplina disciplinaAssegnata){
        docenti.add( new Docente(matricolaDocente,  nome,  cognome,  disciplinaAssegnata));
    }
    
    
    public ArrayList<Docente> visualizzaDocenti(){
        return docenti;
    }
}
