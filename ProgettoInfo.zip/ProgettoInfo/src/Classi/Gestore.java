/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classi;

/**
 *
 * @author wuyi
 */
class Gestore {

    private GestioneDiscipline gd = null;
    private GestioneDocenti gdoc = null;
    private GestioneCorsi gc = null;
    private GestioneStudenti gs=null;
    private GestioneAppelli ga = null;
    GestioneLettura gl= new GestioneLettura();

    public Gestore() {
        GestioneDiscipline gd = new GestioneDiscipline(gl.readFile("discipline.csv"));
        GestioneDocenti gdoc = new GestioneDocenti(gl.readFile("docenti.csv"));
        GestioneCorsi gc = new GestioneCorsi(gl.readFile("corsi.csv"));
        GestioneStudenti gs = new GestioneStudenti(gl.readFile("studenti.csv"));
        GestioneAppelli ga = new GestioneAppelli(gl.readFile("appelli.csv"));
    }

}
