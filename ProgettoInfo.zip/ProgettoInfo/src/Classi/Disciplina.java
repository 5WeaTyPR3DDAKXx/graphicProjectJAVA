/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classi;

/**
 *
 * @author predieric
 */
public class Disciplina {
    String codiceDisciplina;
    String nomeDisciplina;
    int cfu;
    String codiceCorso;

    public Disciplina(String codiceDisciplina, String nomeDisciplina, int cfu, String codiceCorso) {
        this.codiceDisciplina = codiceDisciplina;
        this.nomeDisciplina = nomeDisciplina;
        this.cfu = cfu;
        this.codiceCorso = codiceCorso;
    }
    
}
