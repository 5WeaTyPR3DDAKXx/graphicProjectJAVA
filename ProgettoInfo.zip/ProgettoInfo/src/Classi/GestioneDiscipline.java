/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classi;

import java.util.ArrayList;

/**
 *
 * @author wuyi
 */
public class GestioneDiscipline {
    private ArrayList<Disciplina>discipline;
    
    
    public void creaDisciplina(String codiceDisciplina,String nomeDisciplina,int cfu,String codiceCorso)
    {
        discipline.add(new Disciplina(codiceDisciplina,nomeDisciplina,cfu,codiceCorso));
    }
    
    
}
