/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classi;

/**
 *
 * @author predieric
 */
public class IscrizioneAppello {
    String idAppello;
    String matricolaStudente;

    public IscrizioneAppello(String idAppello, String matricolaStudente) {
        this.idAppello = idAppello;
        this.matricolaStudente = matricolaStudente;
    }
    
    

}
