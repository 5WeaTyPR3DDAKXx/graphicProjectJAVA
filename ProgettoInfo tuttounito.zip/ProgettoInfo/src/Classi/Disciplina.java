/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classi;

/**
 *
 * @author predieric
 */         
public class Disciplina {
    String codiceDisciplina;
    String nomeDisciplina;
    int cfu;
    Corso corsoDisciplina;// riferimento al corso assegnato 

    public Disciplina(String codiceDisciplina, String nomeDisciplina, int cfu, Corso corsoDisciplina) {
        this.codiceDisciplina = codiceDisciplina;
        this.nomeDisciplina = nomeDisciplina;
        this.cfu = cfu;
        this.corsoDisciplina = corsoDisciplina;
    }

    public String getCodiceDisciplina() {
        return codiceDisciplina;
    }

    @Override
    public String toString() {
        return "Disciplina{" + "codiceDisciplina=" + codiceDisciplina + ", nomeDisciplina=" + nomeDisciplina + ", cfu=" + cfu + ", corsoDisciplina=" + corsoDisciplina + '}';
    }

    public String getNomeDisciplina() {
        return nomeDisciplina;
    }

    public int getCfu() {
        return cfu;
    }

    public Corso getCorsoDisciplina() {
        return corsoDisciplina;
    }

    
}
